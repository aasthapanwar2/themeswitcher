import { createContext,useContext } from "react";

export const ThemeContext = createContext({
    themeMode : "light",
    darkTheme :() =>{},
    LightTheme :() =>{},
})

export const ThemeProvider = ThemeContext.Provider
//you can use this to create a custom hook that will allow you to access the theme context in your components without having to import the context every time.
//function -hook is a function ,use - keyword used with hook

export default function useTheme (){
    return useContext(ThemeContext)
}
// usecontext mai kch context bhi toh den pdega isliye hi toh theme context import kiya tha,ab aapko har jgh do-do jgh import krne ki zrurat nahi hai jese last project mai useState or UserContext kiya tha